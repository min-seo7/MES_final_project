<script setup></script>

<template>
    <div class="layout-footer">
        2조
        <a href="https://primevue.org" target="_blank" rel="noopener noreferrer" class="text-primary font-bold hover:underline"></a>
    </div>
</template>
