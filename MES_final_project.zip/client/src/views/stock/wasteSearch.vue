<script>

</script>

<template>
    <div>
        <div class="font-semibold text-2xl mb-4">폐기물페이지</div>
    </div>
</template>
