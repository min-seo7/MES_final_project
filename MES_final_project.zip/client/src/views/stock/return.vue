<script>
</script>

<template>
    <div>
        <div class="font-semibold text-2xl mb-4">반품페이지</div>
    </div>
</template>
