<script>
</script>

<template>
    <div>
        <div class="font-semibold text-2xl mb-4">재고조회페이지</div>
    </div>

</template>
