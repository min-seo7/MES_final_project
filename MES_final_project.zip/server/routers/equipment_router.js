const express = require("express");
const router = express.Router();

const equipmentService = require("../services/equipment_service.js");


















module.exports = router;
